__title__ = "pycheckoapi"
__description__ = "Python libary for checko.ru API functions"
__url__ = "https://github.com/webcartel-https/pycheckoapi"
__version__ = (0,2)
__build__ = "indev"
__author__ = "IO"
__author_email__ = "prvtangl@gmail.com"
